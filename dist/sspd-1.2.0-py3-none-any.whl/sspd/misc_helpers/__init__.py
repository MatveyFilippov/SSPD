def print_request(text: str):
    print("Local:", text)


def print_response(text: str):
    print("Remote:", text)
