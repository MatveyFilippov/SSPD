from .. import base, checker, exceptions
from ..misc_helpers import io
from ..misc_helpers.paths import FilePath
import os


REQUIREMENTS_FILE = FilePath("requirements.txt")


def execute_remote_command(command: str, raise_on_error: bool | None = True,
                           print_request: bool | None = True, print_response: bool | None = True) -> tuple[int, str]:
    if print_request:
        io.print_request(command)

    _, stdout, stderr = base.SSH_REMOTE_MACHINE.exec_command(command)

    er_text = stderr.read().decode().strip()
    if er_text != "":
        if "[notice]" in er_text:
            io.print_response(er_text)
        else:
            if raise_on_error:
                raise exceptions.SSPDUnhandleableException(er_text)
            if print_response:
                io.print_response(er_text)
            return -1, er_text

    response = stdout.read().decode().strip()
    if response == "":
        response = "OK"
    if print_response:
        io.print_response(response)

    return 0, response


def download_file_from_remote_server(remote_filepath: str, local_filepath: str):
    io.print_info(f"Downloading '{remote_filepath}' to '{local_filepath}'")
    try:
        with open(local_filepath, "wb") as file:
            try:
                base.SFTP_REMOTE_MACHINE.getfo(remote_filepath, file)
            except FileNotFoundError:
                raise exceptions.SSPDUnhandleableException(f"No such file '{remote_filepath}' in remote machine")
        io.print_info("Success")
    except FileNotFoundError:
        raise exceptions.SSPDUnhandleableException(f"Can't write '{local_filepath}' in local machine")


def download_folder_from_remote_server(remote_folderpath: str, local_folderpath: str):
    os.makedirs(local_folderpath, exist_ok=True)
    for item in base.SFTP_REMOTE_MACHINE.listdir(remote_folderpath):
        remote_path = os.path.join(remote_folderpath, item)
        local_path = os.path.join(local_folderpath, item)
        if checker.is_remote_dir(remote_path):
            download_folder_from_remote_server(remote_path, local_path)
        else:
            download_file_from_remote_server(remote_path, local_path)


def send_file_to_remote_server(local_filepath: str, remote_filepath: str):
    try:
        io.print_info(f"Sending '{local_filepath}' to '{remote_filepath}'")
        with open(local_filepath, "rb") as file:
            base.SFTP_REMOTE_MACHINE.putfo(file, remote_filepath)
        io.print_info("Success")
    except FileNotFoundError:
        raise exceptions.SSPDUnhandleableException(f"No such file '{local_filepath}' in local machine")


def stop_running_remote_code(raise_on_error: bool | None = True) -> tuple[int, str]:
    io.print_info("Stop running remote py code")
    return execute_remote_command(f"sudo systemctl stop {base.REMOTE_SERVICE_FILENAME}", raise_on_error=raise_on_error)


def start_running_remote_code(raise_on_error: bool | None = True) -> tuple[int, str]:
    io.print_info("Start running remote py code")
    return execute_remote_command(f"sudo systemctl start {base.REMOTE_SERVICE_FILENAME}", raise_on_error=raise_on_error)


def restart_running_remote_code(raise_on_error: bool | None = True) -> tuple[int, str]:
    io.print_info("Reload daemons")
    execute_remote_command(f"sudo systemctl daemon-reload")
    io.print_info("Restart running remote py code")
    return execute_remote_command(f"sudo systemctl restart {base.REMOTE_SERVICE_FILENAME}", raise_on_error=raise_on_error)


def run_reinstalling_remote_requirements(raise_on_error: bool | None = True) -> tuple[int, str]:
    io.print_info(f"Try to reinstall requirements in remote '{base.CORE_VENV_DIR_NAME}'")
    return execute_remote_command((
        f"{base.REMOTE_PROJECT_DIR_PATH}/{base.CORE_VENV_DIR_NAME}/bin/pip"
        " install -r "
        f"{REQUIREMENTS_FILE.to_absolute(base.REMOTE_PROJECT_DIR_PATH)}"
    ), raise_on_error=raise_on_error)
